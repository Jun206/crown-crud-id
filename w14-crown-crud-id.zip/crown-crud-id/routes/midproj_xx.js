var express = require('express');
var router = express.Router();
// s
/* GET home page. */
router.get('/theme_xx');

module.exports = router;
